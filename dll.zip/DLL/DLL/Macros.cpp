#include "dll.h"

/*
BYTE _stdcall HI_BYTE(WORD wValue)
{
	return HIBYTE(wValue);
}

WORD _stdcall HI_WORD(DWORD dwValue)
{
	return HIWORD(dwValue);
}

BYTE _stdcall LO_BYTE(WORD wValue)
{
	return LOBYTE(wValue);
}

WORD _stdcall LO_WORD(DWORD dwValue)
{
	return LOWORD(dwValue);
}

DWORD _stdcall MAKE_LONG(WORD wLow, WORD wHigh)
{
	return MAKELONG(wLow, wHigh);
}

WORD _stdcall MAKE_WORD(BYTE bLow, BYTE bHigh)
{
	return MAKEWORD(bLow, bHigh);
}*/