#include "dll.h"


#pragma data_seg(".SHARDAT")
	HWND	hError = NULL;
#pragma data_seg()

//typedef long  (_stdcall *vbcall)(long hwnd, long uMsg, long wParam, long lParam);


void _stdcall Error_Message(HWND hObj)
{
	hError = hObj;
}

void Error_API(LPSTR sFunction)
{
	LPVOID vDescription;
	const ULONG ulError = GetLastError();
	
    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, ulError, 0, (LPTSTR) &vDescription, 0, NULL);
    
	
	PostMessage(hError, WM_USER, (WPARAM)ulError, (LPARAM)sFunction);
	
	LocalFree(vDescription);
}

/*LONG CALLBACK ExceptionHandler(LPEXCEPTION_POINTERS ExceptionPtrs)
{   
	//PostMessage(hError, WM_USER, (WPARAM)ExceptionPtrs->ExceptionRecord->ExceptionCode, NULL);
    //vbcall vbFunc;
    //vbFunc = (vbcall)hError;
	//vbFunc(0, WM_USER, ExceptionPtrs->ExceptionRecord->ExceptionCode, 0);

    //Exception_Error ExceptionPtrs.EXCEPTION_RECORD.ExceptionCode, "ExceptionHandler"
    if (ExceptionPtrs->ExceptionRecord->ExceptionFlags == EXCEPTION_NONCONTINUABLE)
	{
		
		//RaiseException(1, NULL, NULL, NULL);
		return EXCEPTION_CONTINUE_SEARCH;
	}
    else
	{
		//MessageBox(NULL, "","", 0);
		return EXCEPTION_CONTINUE_SEARCH;
	}
}*/