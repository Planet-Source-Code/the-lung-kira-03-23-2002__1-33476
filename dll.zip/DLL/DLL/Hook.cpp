#include "dll.h"


#pragma data_seg(".SHARDAT")
	HWND	khHwnd = NULL;
	HHOOK	khHook = NULL;
	HWND	mhHwnd = NULL;
	HHOOK	mhHook = NULL;
	HWND	shHwnd = NULL;
	HHOOK	shHook = NULL;
#pragma data_seg()


HHOOK _stdcall KeyboardHook_Install(HWND hObj)
{
	khHwnd = hObj;

	khHook = SetWindowsHookEx(WH_KEYBOARD, (HOOKPROC)KeyboardHook_Proc, hInst, 0);
	if (khHook == NULL) Error_API("SetWindowsHookEx");
	
	return khHook;
}

void _stdcall KeyboardHook_Remove()
{
	if (UnhookWindowsHookEx(khHook) == 0) Error_API("UnhookWindowsHookEx");
}

LRESULT CALLBACK KeyboardHook_Proc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0)
	{
		return CallNextHookEx(khHook, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION)
	{
		if (PostMessage(khHwnd, WM_USER + 3, wParam, lParam) == 0) Error_API("PostMessage");
	}

	return 0;
}


HHOOK _stdcall MouseHook_Install(HWND hObj)
{
	mhHwnd = hObj;

	mhHook = SetWindowsHookEx(WH_MOUSE, (HOOKPROC)MouseHook_Proc, hInst, 0);
	if (mhHook == NULL) Error_API("SetWindowsHookEx");
	
	return mhHook;
}

void _stdcall MouseHook_Remove()
{
	if (UnhookWindowsHookEx(mhHook) == 0) Error_API("UnhookWindowsHookEx");
}

LRESULT CALLBACK MouseHook_Proc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0)
	{
		return CallNextHookEx(mhHook, nCode, wParam, lParam);
	}
	else
	{
		if (nCode == HC_ACTION)
		{
			//PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
			//((MOUSEHOOKSTRUCT*) lParam)->pt.x,
			//((MOUSEHOOKSTRUCT*) lParam)->pt.y));
			
			if (PostMessage(mhHwnd, WM_USER + 2, wParam, MAKEWPARAM(((MOUSEHOOKSTRUCT*) lParam)->pt.x, ((MOUSEHOOKSTRUCT*) lParam)->pt.y)) == 0) Error_API("PostMessage");
		}
		
		return CallNextHookEx(mhHook, nCode, wParam, lParam);
	}
}



HHOOK _stdcall ShellHook_Install(HWND hObj)
{
	shHwnd = hObj;
	
	shHook = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellHook_Proc, hInst, 0);
	if (shHook == NULL) Error_API("SetWindowsHookEx");
	
	return shHook;
}

void _stdcall ShellHook_Remove()
{
	if (UnhookWindowsHookEx(shHook) == 0) Error_API("UnhookWindowsHookEx");
}

LRESULT CALLBACK ShellHook_Proc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	CallNextHookEx(shHook, nCode, wParam, lParam);
	if (PostMessage(shHwnd, nCode, wParam, lParam) == 0) Error_API("PostMessage");
	
	return 0;
}