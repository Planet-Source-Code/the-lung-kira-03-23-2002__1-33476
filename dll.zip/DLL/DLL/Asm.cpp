#include "dll.h"


void _stdcall cpuid_(ULONG inpEAX, ULONG *outEAX, ULONG *outEBX, ULONG *outECX, ULONG *outEDX)
{
	ULONG ulEAX;
	ULONG ulEBX;
	ULONG ulECX;
	ULONG ulEDX;
	
	_asm
	{
		mov		eax, inpEAX
		cpuid
		
		mov		ulEAX, eax
		mov		ulEBX, ebx
		mov		ulECX, ecx
		mov		ulEDX, edx
	}
	
	*outEAX = ulEAX;
	*outEBX = ulEBX;
	*outECX = ulECX;
	*outEDX = ulEDX;
}
/*
void _stdcall cpuspeed(ULARGE_INTEGER *tsc)
{
	ULARGE_INTEGER r_bef_tsc;
	ULARGE_INTEGER r_aft_tsc;
	LARGE_INTEGER t_bef_tsc;
	LARGE_INTEGER t_aft_tsc;
	LARGE_INTEGER t_freq_tsc;
	
	QueryPerformanceFrequency(&t_freq_tsc);
	QueryPerformanceCounter(&t_bef_tsc);
	_asm
	{
		rdtsc
		mov r_bef_tsc.HighPart,edx
		mov r_bef_tsc.LowPart,eax
	}
	Sleep(1000);
	_asm
	{
		rdtsc
		mov r_aft_tsc.HighPart,edx
		mov r_aft_tsc.LowPart,eax
	}
	QueryPerformanceCounter(&t_aft_tsc);
	
	//t_bef_tsc.QuadPart = t_bef_tsc.QuadPart / t_freq_tsc.QuadPart;
	//t_aft_tsc.QuadPart = t_aft_tsc.QuadPart / t_freq_tsc.QuadPart;
	t_aft_tsc.QuadPart = t_aft_tsc.QuadPart - t_bef_tsc.QuadPart;
	t_aft_tsc.QuadPart = t_aft_tsc.QuadPart - t_freq_tsc.QuadPart;
	t_aft_tsc.QuadPart = (t_aft_tsc.QuadPart / t_freq_tsc.QuadPart) * 100;
	
	r_aft_tsc.QuadPart = r_aft_tsc.QuadPart - r_bef_tsc.QuadPart;
	r_aft_tsc.QuadPart = r_aft_tsc.QuadPart - (r_aft_tsc.QuadPart / t_aft_tsc.QuadPart );
	
	*tsc = r_aft_tsc;
}*/

void _stdcall rdtsc_(ULARGE_INTEGER *tsc)
{
	ULARGE_INTEGER t_tsc;
	_asm
	{
		rdtsc
		mov t_tsc.HighPart,edx
		mov t_tsc.LowPart,eax
	}
	
	*tsc = t_tsc;
}
