#include "dll.h"


HINSTANCE hInst;


LPSTR _stdcall ltoa_(long value, LPSTR sbuffer, int radix)
{
	char cbuffer[33];
	ltoa(value, cbuffer, radix);
	
    if (strlen(sbuffer) >= strlen(cbuffer))
    {
		strcpy(sbuffer, cbuffer);
	}
	
	return sbuffer;
}

LPSTR _stdcall ultoa_(unsigned long value, LPSTR sbuffer, int radix)
{
	char cbuffer[33];
	ultoa(value, cbuffer, radix);
	
	
    if (strlen(sbuffer) >= strlen(cbuffer))
    {
		strcpy(sbuffer, cbuffer);
	}
	
	return sbuffer;
}


long _stdcall strtol_(const char* ptr, int base)
{
	return strtol(ptr, NULL, base);
}

unsigned long _stdcall strtoul_(const char* ptr, int base)
{
	return strtoul(ptr, NULL, base);
}


int _stdcall inp_(unsigned short port)
{
	return inp(port);
}

unsigned short _stdcall inpw_(unsigned short port)
{
	return inpw(port);
}

int _stdcall outp_(unsigned short port, int data)
{
	return outp(port, data);
}

unsigned short _stdcall outpw_(unsigned short port, unsigned short data)
{
	return outpw(port, data);
}


USHORT _stdcall checksum(USHORT *buffer, int size)
{
	unsigned long cksum = 0;

	while (size > 1) 
	{
		cksum+=*buffer++;
		size -=sizeof(USHORT);
	}

	if (size)
	{
		cksum += *(UCHAR*)buffer;
	}
	
	cksum = (cksum >> 16) + (cksum & 0xffff);
	cksum += (cksum >> 16);
	
	return (USHORT)(~cksum);
}



BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID) 
{
	switch (fdwReason)
	{
		case DLL_PROCESS_ATTACH:
			if (DisableThreadLibraryCalls(hinstDLL) == 0) Error_API("DisableThreadLibraryCalls");
			hInst = hinstDLL;

			break;
	}
	
	return TRUE;
}