#include <windows.h>


bool _stdcall Function_Exist(LPSTR Module, LPSTR Function);
void Errors(LPSTR apiFunction);


bool _stdcall Function_Exist(LPSTR strModule, LPSTR strFunction)
{
	HMODULE hHandle;
	bool bRet;

	hHandle = GetModuleHandle(strModule);
	if (hHandle == NULL)
	{
		Errors("GetModuleHandle");
		
		hHandle = LoadLibraryEx(strModule, NULL, NULL);
		if (hHandle == NULL) Errors("LoadLibraryEx");

		if (GetProcAddress(hHandle, strFunction) == NULL)
		{
			Errors("GetProcAddress");
			bRet = false;
		}
		else
		{
			bRet = true;
		}
		
		if (FreeLibrary(hHandle) == false) Errors("FreeLibrary");
		return bRet;
	}
	else
	{
		if (GetProcAddress(hHandle, strFunction) == NULL)
		{
			Errors("GetProcAddress");
			bRet = false;
		}
		else
		{
			bRet = true;
		}

		return bRet;
	}
}