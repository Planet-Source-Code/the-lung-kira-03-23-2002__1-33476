#include <windows.h>
#include <windowsx.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>


extern HINSTANCE hInst;
extern LPTOP_LEVEL_EXCEPTION_FILTER oldExceptionFilter;


void _stdcall cpuid_(ULONG inpEAX, ULONG *outEAX, ULONG *outEBX, ULONG *outECX, ULONG *outEDX);
void _stdcall rdtsc_(ULARGE_INTEGER *tsc);

LPSTR _stdcall ltoa_(long value, LPSTR sbuffer, int radix);
LPSTR _stdcall ultoa_(unsigned long value, LPSTR sbuffer, int radix);
long _stdcall strtol_(const char* ptr, int base);
unsigned long _stdcall strtoul_(const char* ptr, int base);

int _stdcall inp_(unsigned short port);
unsigned short _stdcall inpw_(unsigned short port);
int _stdcall outp_(unsigned short port, int data);
unsigned short _stdcall outpw_(unsigned short port, unsigned short data);

USHORT _stdcall checksum(USHORT *buffer, int size);

void _stdcall Error_Message(HWND hObj);
void Error_API(LPSTR sFunction);
LONG CALLBACK ExceptionHandler(LPEXCEPTION_POINTERS ExceptionPtrs);

/*BYTE _stdcall HI_BYTE(WORD wValue);
WORD _stdcall HI_WORD(DWORD dwValue);
BYTE _stdcall LO_BYTE(WORD wValue);
WORD _stdcall LO_WORD(DWORD dwValue);
DWORD _stdcall MAKE_LONG(WORD wLow, WORD wHigh);
WORD _stdcall MAKE_WORD(BYTE bLow, BYTE bHigh);*/

HHOOK _stdcall KeyboardHook_Install(HWND hObj);
void _stdcall KeyboardHook_Remove();
LRESULT CALLBACK KeyboardHook_Proc(int nCode, WPARAM wParam, LPARAM lParam);

HHOOK _stdcall MouseHook_Install(HWND hObj);
void _stdcall MouseHook_Remove();
LRESULT CALLBACK MouseHook_Proc(int nCode, WPARAM wParam, LPARAM lParam);

HHOOK _stdcall ShellHook_Install(HWND hObj);
void _stdcall ShellHook_Remove();
LRESULT CALLBACK ShellHook_Proc(int nCode, WPARAM wParam, LPARAM lParam);